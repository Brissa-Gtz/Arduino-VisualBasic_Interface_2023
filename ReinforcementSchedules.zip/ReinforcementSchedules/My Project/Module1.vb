﻿Module Module1
    Public vFile As String = ""
    Public Lever1 As String = ""
    Public Lever2 As String = ""
    Public vTimeStart As Integer
    Public vTimeNow As Integer
    Public Actual_Response(1) As String
    Public Previous_Response(1) As String
    Public RefCount(1) As Integer
    Public refRdy(1) As Boolean
    Public VIList(1) As List(Of Integer)
    Public RatioCount(1) As Integer
    Public RatioGoal(1) As Integer
    Public ResponseCount(1) As Integer
End Module
